#ifndef ENV_H
#define ENV_H

#include <cpp-effects.h>
namespace eff = cpp_effects;

// ------------
// Interface
// ------------

// The interface consists of "abstract commands".

// The Ask command returns the value of a context-dependent variable.
template <typename T>
struct Ask : eff::command<T> {};

// We wrap the command invocation in a function for ergonomics (and to
// hide how commands are invoked).
template <typename T>
T ask() {
  return eff::invoke_command(Ask<T>{});
}

// ----------------
// Implementation
// ----------------

// Handles a computation () -> () ! {Ask}
// Interprets the command Ask as a bound variable.
template <typename T>
class HEnvironment : public eff::handler<void, void, Ask<T>> {
public:
  HEnvironment(T value) : theValue(value) { }
private:
  T theValue; // a store for the value of the context-dependent variable.

  // The return clause allows us to manipulate the return value of the
  // handled computation.
  void handle_return() override {}

  // Each handled command has an associated command clause.
  // resume : T -> () ! {}
  using Resume = eff::resumption<void(T)>;
  void handle_command(Ask<T> _cmd, Resume resume) override {
    return std::move(resume).resume(theValue);
  }
};

#endif
