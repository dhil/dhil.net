// Task-based programming with dynamic binding.

#include <iostream>

#include "utils.hpp"
#include "env.hpp"

// A fixed number for tasks for simplicity.
const int NUM_TASKS = 4;

// Some global data container.
static int data[NUM_TASKS];

// Task structure. Note: no mentioning of `task_id`.
void initialise();
void perform_work();
int& fetch_data(int i);
void finalise();

// We will use the following as our "template" for a task.
void worker() {
  initialise();
  perform_work();
  finalise();
}

// Returns a reference to some task-specific data.
int& fetch_data(int i) {
  return data[i];
}

// The "main body" for our tasks.
void perform_work() {
  int& my_data = fetch_data((int)ask<char>() - (int)'A' /* HACK: do not try this at home. */);
  for (int i = 0; i < 4; i++) {
    std::cout << ask<char>() << ": my data is " << my_data << std::endl;
    my_data = my_data + 1;
  }
}

// Main entry point.
int main() {
  // Initialise the global data.
  for (int i = 0; i < NUM_TASKS; i++)
    data[i] = i+1;
  print_int_array(NUM_TASKS, data);

  // Spawn NUM_TASKS.
  for (int i = 0; i < NUM_TASKS; i++) {
    std::cout << "main" << std::endl;
    eff::handle<HEnvironment<char>>(worker, (char)(i+(int)'A')); // Handler installation.
  }

  print_int_array(NUM_TASKS, data);
  return 0;
}

void initialise() {
  std::cout << ask<char>() << ": initialising" << std::endl;
}

void finalise() {
  std::cout << ask<char>() << ": finalising" << std::endl;
}
