// Setting the stage: Task-based programming with explicit state
// passing.

#include <iostream>

#include "utils.hpp"

// A fixed number for tasks for simplicity.
const int NUM_TASKS = 4;

// Some global data container.
static int data[NUM_TASKS];

// Task structure.
void initialise(char task_id);
void perform_work(char task_id);
int& fetch_data(int i);
void finalise(char task_id);

// We will use the following as our "template" for a task.
void worker(char task_id) {
  initialise(task_id);
  perform_work(task_id);
  finalise(task_id);
}

// Returns a reference to some task-specific data.
int& fetch_data(int i) {
  return data[i];
}

// The "main body" for our tasks.
void perform_work(char task_id) {
  int& my_data = fetch_data((int)task_id - (int)'A' /* HACK: do not try this at home. */);
  for (int i = 0; i < 4; i++) {
    std::cout << task_id << ": my data is " << my_data << std::endl;
    my_data = my_data + 1;
  }
}

// Main entry point
int main() {
  // Initialise the global data.
  for (int i = 0; i < NUM_TASKS; i++)
    data[i] = i+1;
  print_int_array(NUM_TASKS, data);

  // Spawn NUM_TASKS.
  for (int i = 0; i < NUM_TASKS; i++) {
    std::cout << "main" << std::endl;
    worker((char)(i+(int)'A'));
  }

  print_int_array(NUM_TASKS, data);
  return 0;
}

void initialise(char task_id) {
  std::cout << task_id << ": initialising" << std::endl;
}

void finalise(char task_id) {
  std::cout << task_id << ": finalising" << std::endl;
}
