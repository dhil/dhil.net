// Based on the rollback state example of Ghica et al. (2022).

// Transactional state example.
// This example demonstrates a form of codeable fault tolerance
// expressible with one-shot continuations.
#ifndef H_ROLLBACK
#define H_ROLLBACK

#include <cpp-effects.h>
namespace eff = cpp_effects;

// -----------
// Interface
// -----------

// Rolls back the state of a delimited fragment of the program.
struct Rollback : eff::command<> {};
void rollback() {
  eff::invoke_command(Rollback{});
}

// We require a little boilerplate to set up tracking of variable
// assignments.
//
// The following structures are used to record the assignment of a
// variable.
//
// AssignVarBase is an existential wrapper.
struct AssignVarBase {
  virtual void undo() = 0;
  virtual ~AssignVarBase() {}
};
// AssignVar is polymorphic over the type of the variable.
template<typename T>
struct AssignVar : AssignVarBase {
  T& x;     // a reference to the variable being tracked;
  T value;  // its current value.
  AssignVar(T& var, T newValue) : x(var), value(var) {
    x = newValue;
  }
  virtual void undo() override {
    x = value;
  };
  virtual ~AssignVar() {}
};
// Now we declare our command.
struct AssignCmd : eff::command<> {
  AssignVarBase* base;
};
// We use a syntactic trick to let programmers annotate assignments.
template<typename T>
struct track {
  T& x;
  track(T& var) : x(var) {}
  void operator=(const T& value) {
    eff::invoke_command(AssignCmd{{}, new AssignVar<T>(x, value)});
  }
};

// ----------------
// Implementation
// ----------------

// Handles a computation () -> () ! {Rollback, AssignCmd}.
//
//                                         --- this handler returns a boolean.
//                                         |
class RollbackState : public eff::handler<bool, void, Rollback, AssignCmd> {
  bool handle_return() override {
    return true;  // indicate no faults
  }

  // Handling of Rollback and AssignCmd.
  // resume : () -> bool ! {}
  using Resume = eff::resumption<bool()>;
  bool handle_command(Rollback, Resume) override {
    return false; // indicate a fault occurred
  }
  bool handle_command(AssignCmd assign, Resume resume) override {
    // Evaluate the continuation
    bool result = std::move(resume).resume();
    if (!result) // on fault, rollback the state
      assign.base->undo();
    delete assign.base;
    return result; // propagate the signal
  }
};

#endif
