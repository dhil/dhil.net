#ifndef H_UTILS
#define H_UTILS

#include <iostream>

void print_int_array(int n, int data[n]) {
  std::cout << '[';
  for (int i = 0; i < n; i++) {
    std::cout << data[i];
    if (i+1 < n)
      std::cout << ", ";
  }
  std::cout << ']' << std::endl;
}

#endif
