// Based on the lightweight threading example of Ghica et al. (2022).
#ifndef LWT_H
#define LWT_H
#include <iostream>

#include <cpp-effects.h>
//#include <clause-modifiers.h>
namespace eff = cpp_effects;


// ------------
// Interface
// ------------

// Voluntarily yields control to another task.
struct Yield : eff::command<> {};
void yield() {
  eff::invoke_command(Yield{});
}

// Spawns a new task.
struct Fork : eff::command<> {
  std::function<void()> task;
};
void fork(std::function<void()> task) {
  eff::invoke_command(Fork{{}, task});
}

// ----------------
// Implementation
// ----------------

// resume : () -> () ! {}
using Resume = eff::resumption<void()>;

// Handles a computation () -> () ! {Yield, Fork}
class HScheduler : public eff::handler<void, void, Yield, Fork> {
public:
  // Initiates the scheduler loop, starting with a designated main
  // task.
  static void schedule(std::function<void()> main) {
    // Add main to the queue; but first transform it to a continuation
    // guarded by HScheduler.
    queue.push_back(eff::wrap<HScheduler>(main));

    // Keep going until there is nothing left to do.
    while (!queue.empty()) {
      auto resume = std::move(queue.front());
      queue.pop_front();
      std::move(resume).resume();
    }
  }
private:
  static std::list<Resume> queue; // Our queue structure, a list of continuations

  // Nothing special to do with the return value.
  void handle_return() override {}

  // Handling of Yield and Fork.
  void handle_command(Yield, Resume r) override {
    queue.push_back(std::move(r));
  }

  void handle_command(Fork f, Resume r) override {
    queue.push_back(std::move(r));
    queue.push_back(eff::wrap<HScheduler>(f.task));
  }
};

std::list<Resume> HScheduler::queue;
#endif
