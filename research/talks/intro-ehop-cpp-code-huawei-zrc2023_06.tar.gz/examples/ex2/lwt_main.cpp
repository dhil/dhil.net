#include <iostream>

#include "utils.hpp"
#include "lwt.hpp"

// A fixed number for tasks for simplicity.
const int NUM_TASKS = 4;

// Some global data container.
static int data[NUM_TASKS];

void initialise(char task_id);
void perform_work(char task_id);
int& fetch_data(int i);
void finalise(char task_id);

void worker(char task_id) {
  initialise(task_id);
  perform_work(task_id);
  finalise(task_id);
}

int& fetch_data(int i) {
  return data[i];
}

void perform_work(char task_id) {
  int& my_data = fetch_data((int)task_id - (int)'A');
  for (int i = 0; i < 4; i++) {
    std::cout << task_id << ": my data is " << my_data << std::endl;
    my_data = my_data + 1;
    yield();
  }
}

int main() {
  // Initialise the global data.
  for (int i = 0; i < NUM_TASKS; i++)
    data[i] = i+1;
  print_int_array(NUM_TASKS, data);

  HScheduler::schedule([]() {
    // Spawn NUM_TASKS.
    for (int i = 0; i < NUM_TASKS; i++) {
      std::cout << "main" << std::endl;
      fork([=]() { worker((char)((int)'A' + i)); });
    }
  });

  print_int_array(NUM_TASKS, data);
  return 0;
}

void initialise(char task_id) {
  std::cout << task_id << ": initialising" << std::endl;
}

void finalise(char task_id) {
  std::cout << task_id << ": finalising" << std::endl;
}
