#include <iostream>

#include "utils.hpp"
#include "env.hpp"
#include "lwt.hpp"

// A fixed number for tasks for simplicity.
const int NUM_TASKS = 4;

// Some global data container.
static int data[NUM_TASKS];

void initialise();
void perform_work();
int& fetch_data(int i);
void finalise();

void worker() {
  initialise();
  perform_work();
  finalise();
}

int& fetch_data(int i) {
  return data[i];
}

void perform_work() {
  int& my_data = fetch_data((int)ask<char>() - (int)'A');
  for (int i = 0; i < 4; i++) {
    std::cout << ask<char>() << ": my data is " << my_data << std::endl;
    my_data = my_data + 1;
    yield();
  }
}

// Compose schedule(env(...)) to endow each thread with thread-local
// state.

int main() {
  // Initialise the global data.
  for (int i = 0; i < NUM_TASKS; i++)
    data[i] = i+1;
  print_int_array(NUM_TASKS, data);

  HScheduler::schedule([]() {
    // Spawn NUM_TASKS.
    for (int i = 0; i < NUM_TASKS; i++) {
      std::cout << "main" << std::endl;
      fork([=]() {
        // Enclose each worker in an environment handler.
        eff::handle<HEnvironment<char>>(worker, (char)((int)'A' + i));
      });
    }
  });

  print_int_array(NUM_TASKS, data);
  return 0;
}



// Alternative: compose env(schedule(...)) to make each thread share
// the same global state.

// int main() {
//   // Initialise the global data.
//   for (int i = 0; i < NUM_TASKS; i++)
//     data[i] = i+1;
//   print_int_array(NUM_TASKS, data);

//   eff::handle<HEnvironment<char>>([]() {
//     HScheduler::schedule([]() {
//       // Spawn NUM_TASKS.
//       for (int i = 0; i < 4; i++) {
//         std::cout << "main" << std::endl;
//         fork(worker);
//       }
//     });
//   }, 'A');

//   print_int_array(NUM_TASKS, data);
//   return 0;
// }


void initialise() {
  std::cout << ask<char>() << ": initialising" << std::endl;
}

void finalise() {
  std::cout << ask<char>() << ": finalising" << std::endl;
}
