#ifndef EHOP_TALK_LWT_H
#define EHOP_TALK_LWT_H

#include <seff.h>
#include <queue.h>

//
// Example: lightweight threads (infrastructure)
//

// The lightweight thread (lwt) effect contains of two operations:
//
//    yield : void
//    fork : { fn_t f; void *arg } -> void
//
// The former operation yields control, whilst the latter creates a
// new thread. The latter is parameterised by a function `f`, which is
// to be run on the new thread, and an initial argument.

// The yield operation.
DEFINE_EFFECT(yield, 2, void*, { void *unused; });
void yield(void) {
  (void)PERFORM(yield, NULL);
}

// The fork operation.
typedef void*(*fn_t)(void*);
DEFINE_EFFECT(fork, 3, void*, { fn_t f; void *arg; });
void fork(fn_t fn, void *arg) {
  (void)PERFORM(fork, fn, arg);
}


// Handling the lwt effect corresponds to implementing a scheduler.
// This handler implements a scheduler that uses a FIFO queue policy.
void* handle_lwt_fifo(seff_coroutine_t *main) {
  // We commit to handling yield and fork.
  effect_set handles_lwt = HANDLES(yield) | HANDLES(fork);

  // Setup our queue.

  // The queue enqueues and dequeues elements of type `co_clo_t`
  // defined as:
  // struct co_clo {
  //  seff_coroutine_t *co;
  //  void *arg;
  // };
  // It is a closure over a coroutine. We do not actually not need the
  // closure facility here, but we will see it comes in handy in a
  // later example.
  queue_t q = QUEUE_INITIALISER;
  // Enqueue the main thread.
  queue_pushrear(&q, (co_clo_t){ .co = main, .arg = NULL });

  // Whilst there is work to do, keep dequeuing threads.
  while (!queue_is_empty(&q)) {
    // Take the next thread from the front of the queue.
    co_clo_t cur = queue_popfront(&q);
    // Continue the thread.
    seff_request_t req = seff_handle(cur.co, NULL, handles_lwt);

    // Now handle its effects.
    switch (req.effect) {
      // The thread yielded.
      CASE_EFFECT(req, yield, {
          // We push the thread on to the rear of the queue.
          queue_pushrear(&q, cur);
          break;
        })
      // The thread forked another thread.
      CASE_EFFECT(req, fork, {
          // Extract the function `f` and its argument. Place them on
          // a new coroutine.
          seff_coroutine_t *co = seff_coroutine_new(payload.f, payload.arg);
          // Now push the forkee onto the queue, and afterwards the
          // forker.
          queue_pushrear(&q, (co_clo_t){ .co = co, .arg = NULL });
          queue_pushrear(&q, cur);
          break;
        })
      // The thread finished.
      CASE_RETURN(req, {
          seff_coroutine_delete(cur.co);
          break;
        })
    }
  }
  return NULL;
}

// Same as above, but uses a LIFO queue policy.
void* handle_lwt_lifo(seff_coroutine_t *main) {
  effect_set handles_lwt = HANDLES(yield) | HANDLES(fork);

  queue_t q = QUEUE_INITIALISER;
  queue_pushrear(&q, (co_clo_t){ .co = main, .arg = NULL });

  while (!queue_is_empty(&q)) {
    co_clo_t cur = queue_poprear(&q); // Popping from the rear rather than front.
    seff_request_t req = seff_handle(cur.co, NULL, handles_lwt);

    switch (req.effect) {
      CASE_EFFECT(req, yield, {
          queue_pushrear(&q, cur);
          break;
        })
      CASE_EFFECT(req, fork, {
          seff_coroutine_t *co = seff_coroutine_new(payload.f, payload.arg);
          queue_pushrear(&q, (co_clo_t){ .co = co, .arg = NULL });
          queue_pushrear(&q, cur);
          break;
        })
      CASE_RETURN(req, {
          seff_coroutine_delete(cur.co);
          break;
        })
    }
  }
  return NULL;
}
#endif
