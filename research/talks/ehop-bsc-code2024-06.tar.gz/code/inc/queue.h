#ifndef EHOP_TALK_QUEUE_H
#define EHOP_TALK_QUEUE_H

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <seff.h>

#define QUEUE_SIZE 100

typedef struct co_closure {
  seff_coroutine_t *co;
  void *arg;
} co_clo_t;

typedef struct queue {
  co_clo_t q[QUEUE_SIZE];
  uint32_t front;
  uint32_t rear;
} queue_t;

#define QUEUE_INITIALISER ((struct queue) { .q = {0}, .front = 0, .rear = 0 })

void queue_pushrear(queue_t *q, co_clo_t co) {
  if (q->rear < QUEUE_SIZE) {
    q->q[q->rear++] = co;
  } else if (q->front > 0) {
    memmove(&q->q[0], &q->q[q->front], sizeof(co_clo_t) * (q->rear - q->front));
    q->rear = q->rear - q->front;
    q->front = 0;
    q->q[q->rear++] = co;
  } else {
    assert(q->rear < QUEUE_SIZE || q->front > 0);
    abort();
  }
  return;
}

co_clo_t queue_popfront(queue_t *q) {
  assert(q->front < q->rear);
  return q->q[q->front++];
}

co_clo_t queue_poprear(queue_t *q) {
  assert(q->front < q->rear);
  q->rear -= 1;
  return q->q[q->rear];
}

bool queue_is_empty(const queue_t *q) {
  return q->front == q->rear;
}

#endif
