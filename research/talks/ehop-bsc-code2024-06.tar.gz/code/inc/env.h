#ifndef EHOP_TALK_ENV_H
#define EHOP_TALK_ENV_H

#include <stdbool.h>
#include <seff.h>

//
// Example: Dynamic binding.
//

// Dynamic binding assigns meaning to certain variables depending on
// the _dynamic_ execution context. It is a simple, yet powerful,
// facility which can be used to simulate implicit arguments,
// dependency injection, and more.

// The dynamic binding effect consists of a single operation
//
//   ask : void*
//
// Here we should understand `ask` as a syntactic symbol, whose
// meaning is conferred by the ambient context. Due to C's lack of
// polymorphism we opt to return a void-pointer.
DEFINE_EFFECT(ask, 1, void*, { void *unused; });
void* ask(void) {
  return PERFORM(ask, NULL);
}

// Handling dynamic binding amounts to forwarding a certain value to
// the caller of `ask`.
void* handle_ask(seff_coroutine_t *co, void *value) {
  // We commit to handle `ask`.
  effect_set handles_ask = HANDLES(ask);
  // Locals to hold the return value, and the continuation value of `ask`.
  void *retval = NULL, *contval = NULL;

  // Terminate when done == true.
  bool done = false;
  while (!done) {
    // Run the computation, binding ask -> value.
    seff_request_t req = seff_handle(co, contval, handles_ask);

    // Handle the effects.
    switch (req.effect) {
      // It performed ask.
      CASE_EFFECT(req, ask, {
          // Continue with `value` on the next iteration.
          contval = value;
          break;
      })
      // It returned.
      CASE_RETURN(req, {
          done = true;
          retval = payload.result;
          break;
      })
    }
  }
  return retval;
}

#endif
