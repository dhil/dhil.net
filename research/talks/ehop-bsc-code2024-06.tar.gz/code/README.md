# Instructions

```sh
# First download libseff
$ make libseff
# Then build all examples
$ make all
```
