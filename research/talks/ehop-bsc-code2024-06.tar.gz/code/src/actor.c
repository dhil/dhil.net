#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <env.h>
#include <lwt.h>
#include <seff.h>

#define PACK(x) ((void*)(intptr_t)(x))
#define UNPACK(x) ((int)(intptr_t)(x))

void print_msg(int id, int msg) {
  printf("actor(%d): %d\n", id, msg);
}
MAKE_SYSCALL_WRAPPER(void, print_msg, int, int);
#define PRINT_MSG(id, msg) print_msg_syscall_wrapper((id), (msg))


//
// Example: Obtaining actors by composing state + lwt + dynamic
// binding.
//

// An actor is a process equipped with a mailbox. Actors can
// communicate by sending messages to each others. Upon receiving a
// message an actor can make a local decision on how to respond.


// Actor operation: calling self() within an actor returns its unique
// id.
int self(void) {
  // We may readily implement this function by using the dynamic
  // binding effect from before.
  return UNPACK(ask());
}

// This operation sends a message to a designated actor.
//
//   send : { int receiver; int message } -> void
//
//  It is parameterised by the id of the receiver and the message to
//  be sent. We simply assume that ids are bare ints. In a real system
//  we would implement them as an abstract and unforgeable data type.
DEFINE_EFFECT(send, 4, void*, { int receiver; int message; });
// This wrapper performs "send" and yields control afterwards.
void sendmsg(int receiver, int message) {
  (void)PERFORM(send, receiver, message);
  yield(); // let another actor run.
}

// A bespoke message to signal that no messages are available to the
// enquiring actor.
#define NO_MSG (-2)

// This operation receives a message.
//
//   recv : { int receiver } -> int
//
// It is parameterised by the id of the receiver.
DEFINE_EFFECT(recv, 5, int, { int receiver; });
// This wrapper performs "recv" and yields control if no message is
// available.
int recvmsg(void) {
  int ans = NO_MSG;
  while (ans == NO_MSG) {
    ans = PERFORM(recv, self());
    if (ans == NO_MSG) yield(); // let another actor run.
  }
  return ans;
}

typedef struct mailbox {
  bool has_message;
  int message;
} mailbox_t;


// Handling "recv" and "send" amounts to implementing a store.
void* mailman(seff_coroutine_t *co) {
  // Initialise the mailbox structure.
  #define MAILBOXES 100
  // Mailboxes are indexed by actor ids. For simplicity we assume
  // actors are assigned ids in the range [0,100].
  mailbox_t mailboxes[MAILBOXES];
  for (int i = 0; i < MAILBOXES; i++)
    mailboxes[i] = (mailbox_t){ .has_message = false, .message = 0 };

  // Commit to handling the operations "send" and "recv".
  effect_set handles_mail = HANDLES(send) | HANDLES(recv);
  // A location to hold the message to be returned to an enquiring
  // actor. For "send" it is NULL, for "recv" it is whatever is
  // contained within the respective mailbox or NO_MSG if the mailbox
  // is empty.
  void *msg = NULL;

  // Exit when done = true.
  bool done = false;
  while (!done) {
    // Now run the computation.
    seff_request_t req = seff_handle(co, msg, handles_mail);
    // Handle the effects of co.
    switch (req.effect) {
      // co is sending a message.
      CASE_EFFECT(req, send, {
          // Update the receiver's mailbox.
          mailboxes[payload.receiver].has_message = true;
          mailboxes[payload.receiver].message = payload.message;
          break;
        })
      // co wants to receive a message.
      CASE_EFFECT(req, recv, {
          // First check the mailbox
          if (mailboxes[payload.receiver].has_message) {
            // Consume the message.
            msg = PACK(mailboxes[payload.receiver].message);
            mailboxes[payload.receiver].has_message = false;
          } else {
            // Otherwise inform co that no messages are available.
            msg = PACK(NO_MSG);
          }
          break;
      })
     CASE_RETURN(req, {
         done = true;
         break;
      })
    }
  }
  #undef MAILBOXES
  return NULL;
}

// Type of an actor and an actor closure. The latter is a temporary
// data structure used to initialise a freshly spawned actor.
typedef void*(*actor_t)(void*);
typedef struct actor_closure {
  int id;     // the id aka. self() of the actor.
  actor_t fn; // computation to run within the actor.
} actor_closure_t;

// Initiates a new actor
void* initiate_actor(void *arg) {
  actor_closure_t *clo = (actor_closure_t*)arg;
  actor_t fn = clo->fn;
  int id = clo->id;
  free(clo);

  // Allocate an environment handler to provide an interpretation of
  // the `self` function.
  seff_coroutine_t *co = seff_coroutine_new(fn, NULL);
  void *ans = handle_ask(co, PACK(id)); // binds self -> id
  seff_coroutine_delete(co);

  return ans;
}

// Spawns a new actor within a fresh lightweight thread.
int spawn(actor_t fn) {
  // We assign a new unique id to each actor.
  static int id = 0;
  int next = id++;

  // Allocate a closure to pass the data to the actor wrapper.
  actor_closure_t *clo = malloc(sizeof(actor_closure_t));
  clo->id = next;
  clo->fn = fn;

  // Invoke fork from the LWT effect.
  fork(initiate_actor, clo);

  // Return the id.
  return next;
}

void *lwt_wrapper(void *arg) {
  return handle_lwt_fifo((seff_coroutine_t*)arg);
}

//
// Application: Prime sieve
//

// The idea is to construct a pipeline of actors such as:
//
//   naturals --> filter --> sieve(3) --> sieve(5) --> ... --> sieve(97)
//
// The sieve actors are dynamically spawned whenever a new prime
// number has been discovered.

// A bespoke message to signal termination.
#define HALT (-1)
// A bespoke message used to start the sieve pipeline.
#define GO (-3)

// Actor: streaming naturals numbers in the interval [0,100].
void* naturals(void *arg __attribute__((unused))) {
  // First receive the consumer of the natural numbers.
  int consumer = recvmsg();
  // Next wait on the GO signal.
  while (recvmsg() != GO) {}
  // Hereafter send the numbers one at a time.
  for (int i = 0; i < 100; i++) {
    sendmsg(consumer, i);
  }
  // Finally tell the consumer to shutdown.
  sendmsg(consumer, HALT);
  return NULL;
}

// Actor: prime sieve. An instance of this actor holds a prime and
// uses this to test the potential primality of a new candidate
// number.
void* sieve(void*);
void* sieve(void *arg __attribute__((unused))) {
  int next_instance = -1;
  // First receive my prime number.
  int my_prime = recvmsg();
  // Print "actor(id): my_prime"
  PRINT_MSG(self(), my_prime);

  // Now keep receiving new candidate primes.
  while (true) {
    int candidate = recvmsg();
    // If the candidate is the special HALT message, then terminate.
    if (candidate == HALT) {
      // If this instance has a next kin then forward the termination
      // message.
      if (next_instance != -1) {
        sendmsg(next_instance, HALT);
      }
      break;
    }
    // Otherwise test whether the candidate may be a prime.
    if (candidate % my_prime != 0) {
      // If we don't have a next instance yet, then spawn
      // it. Consequently, this means we have discovered a new prime.
      if (next_instance == -1) {
        next_instance = spawn(sieve);
      }
      // Forward the candidate to the next instance.
      sendmsg(next_instance, candidate);
    }
  }
  return NULL;
}

// Actor: a forwarder which filters out numbers less than 3 and even
// numbers.
void* filter_naturals(void *arg __attribute__((unused))) {
  // Receive the id of the consumer.
  int consumer = recvmsg();
  // Now keep receiving messages and filtering them accordingly.
  while (true) {
    int message = recvmsg();
    if (message == HALT) {
      sendmsg(consumer, HALT);
      break;
    }
    // If the message is too small or is an even number, then skip it.
    if (message < 3 || message % 2 == 0) continue;
    // Otherwise forward the message.
    sendmsg(consumer, message);
  }
  return NULL;
}

// Setup: configures the pipeline computation.
void* pipeline(void *arg __attribute__((unused))) {
  // Create the naturals producer, filter forwarder, and the first
  // sieve actor.
  int nats = spawn(naturals);
  int filter = spawn(filter_naturals);
  int sieve3 = spawn(sieve);

  // Connect the naturals and filter actors.
  sendmsg(nats, filter);
  // Connect the filter and sieve actors.
  sendmsg(filter, sieve3);
  // Initiate the pipeline.
  sendmsg(nats, GO);
  return NULL;
}

int main(void) {
  // Wrap the pipeline in the LWT handler.
  seff_coroutine_t *lwt = seff_coroutine_new(lwt_wrapper, (void*)seff_coroutine_new(pipeline, NULL));
  // Wrap the lwt computation in the mailman handler.
  (void)mailman(lwt);

  seff_coroutine_delete(lwt);
  return 0;
}
