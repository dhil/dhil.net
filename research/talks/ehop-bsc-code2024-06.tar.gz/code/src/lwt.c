#include <stdio.h>
#include <stdlib.h>
#include <lwt.h>

#define PACK(x) ((void*)(intptr_t)(x))
#define UNPACK(x) ((char)(intptr_t)(x))

//
// Example: lightweight threads
//

// Some globals to keep track of the task tree depth and next task id.
static int depth = 0;
static char next_id = 'A';

// A simple task prints its id, forks another task, then yields, and
// finally prints its id again.
void* task(void *arg) {
  char ch = UNPACK(arg);
  // Print id.
  putc(ch, stdout);

  // Decide whether to fork further tasks.
  if (depth < 2) {
    depth += 1;
    fork(task, PACK(next_id++));
  }

  // Yield control to another task.
  yield();

  // Print id.
  putc(ch, stdout);
  return NULL;
}

int main(void) {
  // Schedule using FIFO semantics.
  seff_coroutine_t *main_task = seff_coroutine_new(task, PACK(next_id++));
  (void)handle_lwt_fifo(main_task);
  putc('\n', stdout);

  // Reset the globals.
  next_id = 'A';
  depth = 0;

  // Schedule using LIFO semantics.
  main_task = seff_coroutine_new(task, PACK(next_id++));
  (void)handle_lwt_lifo(main_task);
  putc('\n', stdout);
  return 0;
}
