#include <env.h>
#include <stdio.h>
#include <stdint.h>

#define PACK(x) ((void*)(intptr_t)(x))
#define UNPACK(x) ((int)(intptr_t)(x))

//
// Example: Dynamic binding
//

// This function invokes the symbol `ask` and interprets its result as
// an integer to which it adds 2.
void* add2(void *arg __attribute__((unused))) {
  int x = UNPACK(ask());
  return PACK(2 + x);
}

int main(void) {
  // Lets run three instances of `add2`.
  seff_coroutine_t *co1 = seff_coroutine_new(add2, NULL);
  seff_coroutine_t *co2 = seff_coroutine_new(add2, NULL);
  seff_coroutine_t *co3 = seff_coroutine_new(add2, NULL);

  // We bind `ask` differently in each context.
  int a = UNPACK(handle_ask(co1, PACK(38)));
  int b = UNPACK(handle_ask(co2, PACK(39)));
  int c = UNPACK(handle_ask(co3, PACK(40)));

  // Print out the results.
  printf("%d %d %d\n", a, b, c);

  // Clean-up
  seff_coroutine_delete(co1);
  seff_coroutine_delete(co2);
  seff_coroutine_delete(co3);
  return 0;
}

#undef PACK
#undef UNPACK
