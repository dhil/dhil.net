#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <seff.h>

//
// Example: "Hello World" with coroutines.
//

// This example meant to illustrate the basic facilities of
// libseff. We will use effect handlers / coroutines to encode a
// yield-style generator. We will use two generators to cooperatively
// print out "Hello World".

// A generator takes some input.
struct generator_args {
  int8_t *bytes; // Character sequence.
  uint64_t len; // The length of the character sequence.
};

// The library provides a convenient macro for defining effectful
// operations. The following generates a constant symbol "yield" whose
// argument type is a struct with a single member `value`. Its return
// type is void.
//
// Written in a different notation:
//
//   yield : { int8_t value } -> void
//
// Nitpick: The library conflates effects and operations. In general
// an effect is a collection of operations (we will see examples
// later).
DEFINE_EFFECT(yield, 0, void, { int8_t value; });

// Let us put the "yield" operation to use. We implement a generator
// that yields each of the elements from its input sequence.
void* generator(void *arg) {
  // The library mandates that coroutine-functions have the type
  // void*(*f)(void*) (which is similar to pthread_create). Thus, we
  // have to cast the argument ourselves.
  struct generator_args *args = (struct generator_args*)arg;
  // Next loop through the input.
  for (uint64_t i = 0; i < args->len; i++) {
    // PERFORM is another macro provided by the library. It invokes a
    // given operation with a given payload, and returns a value of
    // whatever return type the operation has. Another way to think of
    // PERFORM is as "raise"/"throw" or "suspend".
    PERFORM(yield, args->bytes[i]);
  }
  return NULL;
}

// We will get to handling yield in a moment...
int8_t handle_yield(seff_coroutine_t *co);

// ... but first, lets try to wire the example program together.
int main(void) {
  // Two input sequences.
  char s1[] = "hlowrd";
  char s2[] = "el ol";

  // Two argument structures.
  struct generator_args co1_args = { .bytes = (int8_t*)s1, .len = strlen(s1) };
  struct generator_args co2_args = { .bytes = (int8_t*)s2, .len = strlen(s2) };

  // Two coroutines.
  seff_coroutine_t *co1 = seff_coroutine_new(generator, &co1_args);
  seff_coroutine_t *co2 = seff_coroutine_new(generator, &co2_args);

  // Note: we are using a bitvector to track which generators have
  // finished.
  int8_t done = 0;
  // Keep going until both generators have finished (0x3 == 0b11)
  while (done != 0x3) {
    // Check whether the first generator has finished.
    if ((done & 0x1) != 0x1) {
      // Otherwise invoke it.
      done |= handle_yield(co2);
    }
    // Same for the second generator.
    if ((done & 0x2) != 0x2) {
      done |= handle_yield(co1) << 1;
    }
  }
  putc('\n', stdout);

  // Clean-up
  seff_coroutine_delete(co1);
  seff_coroutine_delete(co2);
  return 0;
}

// The meaning of `yield` is conferred by an effect
// handler. Operationally, it is instructive to think of an effect
// handler as an exception handler with the ability to resume its
// caught exceptions.
int8_t handle_yield(seff_coroutine_t *co) {
  // First we need to tell the coroutine computation co, which effects
  // we intend to handle.  We commit to handle the "yield" operation.
  effect_set handles_yield = HANDLES(yield);

  // We return a boolean (encoded as a byte) to signal whether the
  // computation suspended or finished.
  int8_t done = 0;

  // Next we run the computation.
  seff_request_t req = seff_handle(co, NULL, handles_yield);
  // The computation can return to here in two ways:
  //  1) It performed yield.
  //  2) It returned normally (i.e. finished)
  switch (req.effect) {
    // It performed yield.
    CASE_EFFECT(req, yield, {
        // Extract the payload.
        int8_t b = payload.value;
        // Our interpretation is to print the payload to stdout.
        putc((char)b, stdout);
        // We are not done yet.
        done = 0;
        break;
    })
    // It returned normally.
    CASE_RETURN(req, {
        // We simply forward the signal.
        done = 1;
        break;
    })
  }
  return done;
}
